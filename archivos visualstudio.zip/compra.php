<?php
include "conexion.php";
session_start();

if (!isset($_SESSION['usuario'])) {
    die("Acceso no autorizado.");
}

$productosSeleccionados = $_POST['productos'] ?? [];

// Obtener el ID del cliente (usaremos el último ID de la tabla clientes como simulación básica)
$stmt = $pdo->query("SELECT id FROM clientes ORDER BY id DESC LIMIT 1");
$cliente = $stmt->fetch();

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Compra Realizada</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="text-center mb-4">
            <h2 class="text-success">✅ Compra realizada con éxito</h2>
            <p class="lead">¡Gracias por tu compra, <?php echo htmlspecialchars($_SESSION['usuario']); ?>!</p>
        </div>

        <?php if (count($productosSeleccionados) > 0): ?>
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Productos comprados
                </div>
                <ul class="list-group list-group-flush">
                    <?php foreach ($productosSeleccionados as $ref): ?>
                        <li class="list-group-item">
                            🛒 Producto Ref: <strong><?php echo htmlspecialchars($ref); ?></strong>
                        </li>
                        <?php
                        // Insertar en la base de datos
                        if ($cliente) {
                            $stmt = $pdo->prepare("INSERT INTO compras (cliente_id, producto_id) VALUES (?, ?)");
                            $stmt->execute([$cliente['id'], $ref]);
                        }
                        ?>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php else: ?>
            <div class="alert alert-warning mt-4">
                No seleccionaste ningún producto.
            </div>
        <?php endif; ?>

        <div class="text-center mt-4">
            <a href="tienda.php" class="btn btn-outline-primary">Volver a la tienda</a>
        </div>
    </div>
</body>
</html>
