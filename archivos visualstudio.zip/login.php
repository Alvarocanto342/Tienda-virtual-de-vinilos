<?php
session_start();
require 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $usuario = $_POST['usuario'] ?? '';
  $password = $_POST['password'] ?? '';

  if (empty($usuario) || empty($password)) {
    die('Por favor, completa todos los campos.');
  }

  $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE usuario = ?");
  $stmt->execute([$usuario]);
  $user = $stmt->fetch();

  if ($user && password_verify($password, $user['contrasena'])) {
    $_SESSION['usuario'] = $usuario;
    header('Location: tienda.php');
  } else {
    echo "Usuario o contraseña incorrectos.";
  }
}
?>
