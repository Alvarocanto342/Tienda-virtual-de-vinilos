<?php
require 'conexion.php';

$registroExitoso = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $usuario = $_POST['usuario'];
  $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
  $nombre = $_POST['nombre'];
  $apellidos = $_POST['apellidos'];
  $correo = $_POST['correo'];
  $fecha = $_POST['fecha_nacimiento'];
  $genero = $_POST['genero'];

  // Insertamos los datos en las tablas
  $pdo->prepare("INSERT INTO usuarios (usuario, contrasena) VALUES (?, ?)")->execute([$usuario, $password]);
  $pdo->prepare("INSERT INTO clientes (nombre, apellidos, correo, fecha_nacimiento, genero) VALUES (?, ?, ?, ?, ?)")->execute([$nombre, $apellidos, $correo, $fecha, $genero]);

  $registroExitoso = true;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registro</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">

    <?php if ($registroExitoso): ?>
      <div class="text-center">
        <h2 class="text-success mb-4">🎉 ¡Registro exitoso!</h2>
        <p class="lead">Gracias por registrarte, <strong><?php echo htmlspecialchars($usuario); ?></strong>.</p>
        <a href="login.html" class="btn btn-primary mt-3">Iniciar sesión</a>
      </div>
    <?php else: ?>
      <h2 class="mb-4">Registro</h2>
      <form action="registro.php" method="POST">
        <div class="mb-3">
          <label for="usuario" class="form-label">Usuario</label>
          <input type="text" class="form-control" name="usuario" required>
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">Contraseña</label>
          <input type="password" class="form-control" name="password" required>
        </div>
        <div class="mb-3">
          <label for="nombre" class="form-label">Nombre</label>
          <input type="text" class="form-control" name="nombre" required>
        </div>
        <div class="mb-3">
          <label for="apellidos" class="form-label">Apellidos</label>
          <input type="text" class="form-control" name="apellidos" required>
        </div>
        <div class="mb-3">
          <label for="correo" class="form-label">Correo</label>
          <input type="email" class="form-control" name="correo" required>
        </div>
        <div class="mb-3">
          <label for="fecha_nacimiento" class="form-label">Fecha de Nacimiento</label>
          <input type="date" class="form-control" name="fecha_nacimiento" required>
        </div>
        <div class="mb-3">
          <label for="genero" class="form-label">Género</label>
          <select name="genero" class="form-select" required>
            <option value="">Selecciona una opción</option>
            <option value="Masculino">Masculino</option>
            <option value="Femenino">Femenino</option>
            <option value="Otro">Otro</option>
          </select>
        </div>
        <button type="submit" class="btn btn-success">Registrarse</button>
      </form>
    <?php endif; ?>

  </div>
</body>
</html>
