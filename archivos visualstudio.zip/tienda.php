<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['usuario'])) {
  header("Location: login.html");
  exit;
}

// Simulamos los productos (como no los sacas de BD aún)
$productos = [
  ['referencia' => 1, 'nombre' => 'Vinilo de Pink Floyd', 'precio' => 20.00],
  ['referencia' => 2, 'nombre' => 'Vinilo de The Beatles', 'precio' => 15.00],
  ['referencia' => 3, 'nombre' => 'Vinilo de Queen', 'precio' => 18.00],
  ['referencia' => 4, 'nombre' => 'Vinilo de Nirvana', 'precio' => 12.00],
  ['referencia' => 5, 'nombre' => 'Vinilo de Led Zeppelin', 'precio' => 22.00],
  ['referencia' => 6, 'nombre' => 'Vinilo de Metallica', 'precio' => 19.00],
  ['referencia' => 7, 'nombre' => 'Vinilo de AC/DC', 'precio' => 17.00],
  ['referencia' => 8, 'nombre' => 'Vinilo de David Bowie', 'precio' => 25.00],
  ['referencia' => 9, 'nombre' => 'Vinilo de The Rolling Stones', 'precio' => 16.00],
  ['referencia' => 10, 'nombre' => 'Vinilo de Bob Marley', 'precio' => 14.00],
];
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Tienda de Vinilos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <h1 class="text-center mb-5">Catálogo de Vinilos</h1>
    <div class="row row-cols-1 row-cols-md-3 g-4">

      <?php foreach ($productos as $producto): ?>
        <div class="col">
          <div class="card h-100">
            <div class="card-body">
              <h5 class="card-title"><?= htmlspecialchars($producto['nombre']) ?></h5>
              <p class="card-text">Precio: €<?= number_format($producto['precio'], 2) ?></p>
              <form method="POST" action="compra.php">
                <input type="hidden" name="productos[]" value="<?= $producto['referencia'] ?>">
                <button type="submit" class="btn btn-primary">Comprar</button>
              </form>
            </div>
          </div>
        </div>
      <?php endforeach; ?>

    </div>
  </div>
</body>
</html>
