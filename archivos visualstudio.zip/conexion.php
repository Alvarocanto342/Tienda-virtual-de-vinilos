<?php
$host = 'localhost';
$db = 'tienda_virtual';
$user = 'root';
$pass = '';
$puerto = 3307;

try {
  $pdo = new PDO("mysql:host=$host;port=$puerto;dbname=$db;charset=utf8", $user, $pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  // echo "Conexión exitosa a la base de datos '$db'.";
} catch (PDOException $e) {
  die("❌ Error de conexión: " . $e->getMessage());
}
?>
